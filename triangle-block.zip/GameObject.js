export class GameObject{
    constructor(position, size){
        this.position = position;
        this.size = size;
        this.isPenetratable = false;
    }
    display(ctx){
        
    };
}

export class Moveable extends GameObject{
    constructor(position,size,speed){
        super(position,size);
        this.speed = speed;
    }
    updatePosition(){
        this.position.x += this.speed.dx;
        this.position.y += this.speed.dy;
    }
}

export class Marble extends Moveable{
    hasCollidedWithBrick(bricks){
        for (let brick of bricks){
            if (brick.isBroken === false){
                if ((this.position.y + this.speed.dy + this.size.radius> brick.position.y) && 
                (this.position.y + this.speed.dy - this.size.radius <  brick.position.y + brick.size.height) && 
                (this.position.x + this.speed.dx + this.size.radius> brick.position.x) && 
                (this.position.x + this.speed.dx - this.size.radius < brick.position.x + brick.size.width)){
                    let minDistance = Infinity;
                    let distanceMarbleLeftSideBrick = Math.abs(brick.position.x - (this.size.radius + this.position.x + this.speed.dx));
                    let distanceMarbleRightSideBrick = Math.abs((this.position.x + this.speed.dx - this.size.radius) - (brick.position.x + brick.size.width));
                    let distanceMarbleUpSideBrick = Math.abs((this.size.radius + this.position.y + this.speed.dy) - brick.position.y);
                    let distanceMarbleDownSideBrick = Math.abs((this.position.y - this.size.radius  + this.speed.dy) - (brick.position.y + brick.size.height));

                    let comingDirection = "";
                    if (minDistance > distanceMarbleLeftSideBrick){
                        comingDirection = "left"; 
                        minDistance = distanceMarbleLeftSideBrick
                    }
                    if (minDistance > distanceMarbleRightSideBrick){
                        comingDirection = "right"; 
                        minDistance = distanceMarbleRightSideBrick
                    }
                    if (minDistance > distanceMarbleUpSideBrick){
                        comingDirection = "up"; 
                        minDistance = distanceMarbleUpSideBrick
                    }
                    if (minDistance > distanceMarbleDownSideBrick){
                        comingDirection = "down"; 
                        minDistance = distanceMarbleDownSideBrick
                    }
                    
                    if (comingDirection === "up" || comingDirection ==="down"){
                        this.speed.dy = -this.speed.dy;
                    }
                    else{
                        this.speed.dx = -this.speed.dx;
                    }
                    brick.updateStatus();
                }
            }
        }
    }

    hasCollidedWithBoundary(canvasWidth, canvasHeight){
        let x = this.position.x;
        let y = this.position.y;
        let dx = this.speed.dx;
        let dy = this.speed.dy;
        let r = this.size.radius;
        
        if (x + dx + r > canvasWidth || x + dx - r < 0){
            if (x + dx + r > canvasWidth){
                this.position.x = canvasWidth - r;
                this.speed.dx = -dx;
                return "right-hit";
            }
            else{
                this.position.x = r;
                this.speed.dx = -dx;
                return "left-hit";
            }
        }
        if (y + dy + r> canvasHeight || y + dy - r< 0){
            if (y + dy + r > canvasHeight){
               return "down-hit";
            }
            else {
                this.position.y = r;
                this.speed.dy = -dy;
                return "up-hit";
            }
        }
        return "no-hit";
    }

    draw(ctx){
        ctx.lineWidth = 2;
        ctx.strokeStyle = "blue";
        ctx.beginPath();
        ctx.arc(this.position.x, this.position.y, this.size.radius, 0, Math.PI*2);
        ctx.stroke();
    }

    hasHitTriangleBrick(brick){
        let a = this.position.x + this.size.radius - brick.vertices[0].x; // 공과 삼각형 왼쪽과의 거리
        let b = this.position.y + this.size.radius - brick.vertices[0].y; // 공과 삼각형 위쪽과의 거리
        let c = Math.abs(this.position.x + this.position.y -(brick.vertices[2].x + brick.vertices[2].y ) / (1.414213)) - this.size.radius;
        let d = this.position.x - this.size.radius - brick.vertices[1].x; // 공과 삼각형을 포함하는 정사각형의 오른쪽과의 거리
        let e = this.position.y - this.size.radius - brick.vertices[2].y; // 공과 삼각형을 포함하는 정사각형의 아래쪽과의 거리

        
        if (a <= 0 && a + this.speed.dx > 0 && b >= 0 && e <= 0) // 왼쪽충돌인경우
            this.speed.dx *= -1;
        else if (b <= 0 && b + this.speed.dy >= 0 && a >= 0 && d <= 0) // 위쪽충돌인경우
            this.speed.dy *= -1;
        else if (a >= 0 && d <= 0 && b >= 0 && e <= 0){ // 대각선 충돌인 경우
            let cMoved = Math.abs(this.position.x + this.speed.dx + this.position.y + this.speed.dy -(brick.vertices[2].x + brick.vertices[2].y ) ) / (1.414213) - this.size.radius;
            if (c >= 0 && cMoved < 0){
                let dx = this.speed.dx;
                let dy = this.speed.dy;
                this.speed.dx = -dy;
                this.speed.dy = -dx;
            }
        }
    }
}

export class LaunchPad extends Moveable{
    constructor(position,size,speed,moveableRange,health){
        super(position,size);
        this.speed = speed;
        this.moveablePosition;
        this.health = health;
        this.launchAngle = 0;
        this.launchDirection = {dx : 0, dy: 1};
    }
    setRandomPosition(){
        this.position.x = Math.random() * (this.moveableRange.max - this.moveableRange.min) + this.moveableRange.min;
    }

    setLaunchAngle(angle){
        this.launchAngle = angle;
        this.setLaunchDirection(angle);
    }

    setLaunchDirection(angle){
        let angleRad = angle / 180 * Math.PI;
        let x, y, s;
        y= 1;
        x = Math.tan(angleRad);
        s = Math.sqrt(y + x * x);
        this.launchDirection = {dx : x/s, dy: y/s};
    }

    locate(){

    }
    draw(ctx){
        this.drawLaunchPad(ctx);
        this.drawLaunchDirection(ctx);
    }
    drawLaunchPad(ctx){
        ctx.beginPath();
        ctx.fillRect(this.position.x, this.position.y, this.size.width, this.size.height);
        ctx.stroke();
    }
    drawLaunchDirection(ctx){
        ctx.beginPath();
        ctx.strokeStyle = "blue";
        ctx.moveTo(this.position.x + 50, this.position.y);
        ctx.lineTo(this.position.x + 50 + this.launchDirection.dx * 100, this.position.y - this.launchDirection.dy * 100);
        ctx.stroke();
    }
}




export class Brick extends Moveable{
    constructor(position, size, health){
        super(position, size);
        this.health = health;
        this.isBroken = false;
    }
    updateStatus(){
        if (this.health > 0){
            this.health --;
            if (this.health ===0){
            this.isBroken = true;
            }
        }
    }
    move(){
        this.position.y += this.size.height;
    }
    
    draw(ctx){
        if (this.isBroken === false){
            ctx.font = "30px Arial";
            ctx.fillText(this.health.toString(),this.position.x + 30, this.position.y + 30);
            ctx.lineWidth = 4;
            ctx.strokeStyle = "yellow";
            ctx.beginPath();
            ctx.strokeRect(this.position.x,this.position.y,this.size.width,this.size.height);
        }
    }

}