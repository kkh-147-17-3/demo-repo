export default function TriangleBlock(blockLocation, size, triangleType, health){
    let vertices = [];
    
    //vertices[0]에는 직각을 품은 꼭지점이 항상 저장된다.
    switch(triangleType){
        case 1: //  |-/
            vertices.push({x: blockLocation.x, y : blockLocation.y});
            vertices.push({x: blockLocation.x + size, y: blockLocation.y});
            vertices.push({x: blockLocation.x, y: blockLocation.y + size});
        break; //   \-|
        case 2:
            vertices.push({x: blockLocation.x + size, y: blockLocation.y});
            vertices.push({x: blockLocation.x, y : blockLocation.y});
            vertices.push({x: blockLocation.x+size, y: blockLocation.y + size});
        break;
        case 3: // |_\
            vertices.push({x: blockLocation.x, y: blockLocation.y + size});
            vertices.push({x: blockLocation.x, y : blockLocation.y});
            vertices.push({x: blockLocation.x+size, y: blockLocation.y + size});
        break;
        case 4://   /_|
            vertices.push({x: blockLocation.x + size, y: blockLocation.y + size});
            vertices.push({x: blockLocation.x, y : blockLocation.y + size});
            vertices.push({x: blockLocation.x+size, y: blockLocation.y});
        break;
    }
    
    
    this.vertices = vertices;
    this.triangleType = triangleType || 1;
    this.health = health || 0;
}

TriangleBlock.prototype = {
    draw : function(ctx){
        ctx.beginPath();
        ctx.moveTo(this.vertices[0].x, this.vertices[0].y);
        ctx.lineTo(this.vertices[1].x, this.vertices[1].y);
        ctx.lineTo(this.vertices[2].x, this.vertices[2].y);
        ctx.lineTo(this.vertices[0].x, this.vertices[0].y);
        ctx.stroke();
    }
}