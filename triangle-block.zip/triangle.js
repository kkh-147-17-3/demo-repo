import { Marble } from "./GameObject.js";
import TriangleBlock from "./triangle-block.js";



const startMenu = document.getElementById("start");

const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
console.log(ctx);

const CANVAS_WIDTH = canvas.width =700;
const CANVAS_HEIGHT = canvas.height = 700;


let v1 = {x : 300, y :300};
let v2 = {x : 300, y :400};
let v3 = {x : 400, y : 300};
let triangle1 = new TriangleBlock(v1, 100, 1,10);
let triangle2 = new TriangleBlock(v3, 100, 1,10);

let marble1 = new Marble({x : 600, y: 100}, {radius :10}, {dx : -10, dy : -15});
let marble2 = new Marble({x : 500, y: 60}, {radius :10}, {dx : -5, dy : -15});
let marble3 = new Marble({x : 500, y: 80}, {radius :10}, {dx : -4, dy : -15});
let marble4 = new Marble({x : 300, y: 100}, {radius :10}, {dx : -3, dy : -15});
let marble5 = new Marble({x : 200, y: 200}, {radius :10}, {dx : -10, dy : -15});
let marble6 = new Marble({x : 100, y: 300}, {radius :10}, {dx : -9, dy : -15});
let marble7 = new Marble({x : 50, y: 400}, {radius :10}, {dx : -7, dy : -15});
let marble8 = new Marble({x : 30, y: 100}, {radius :10}, {dx : -8, dy : -15});
let marble9 = new Marble({x : 200, y: 60}, {radius :10}, {dx : -10, dy : -15});

let marbles = [marble1, marble2, marble3, marble4, marble5, marble6, marble7, marble8, marble9]


function animate(){
    ctx.clearRect(0,0,CANVAS_WIDTH,CANVAS_HEIGHT);
    triangle1.draw(ctx);
    triangle2.draw(ctx);
    for (let marble of marbles){
        marble.draw(ctx);
        let xCordinate = marble.position.x;
        let yCordinate = marble.position.y;
        let dx = marble.speed.dx;
        let dy = marble.speed.dy;
        let radius = marble.size.radius;
        if (xCordinate + dx + radius > CANVAS_WIDTH || xCordinate + dx - radius < 0){
            if (xCordinate + dx + radius > CANVAS_WIDTH){
                marble.position.x = CANVAS_WIDTH - radius;
            }
            else{
                marble.position.x = radius;
            }
            marble.speed.dx = -dx;
        }
        if (yCordinate + dy + radius> CANVAS_HEIGHT || yCordinate + dy - radius< 0){
            if (yCordinate + dy + radius > CANVAS_HEIGHT){
                marble.position.y = CANVAS_HEIGHT - radius;
            }
            else {
                marble.position.y = radius;
            }
            marble.speed.dy = -dy;
        }
        
        marble.hasHitTriangleBrick(triangle1);
        marble.hasHitTriangleBrick(triangle2);

        marble.updatePosition();
    }
    window.requestAnimationFrame(animate);
}
animate();



